// 1. Script para Scroll Suave
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault(); // Impede o salto imediato

        const targetId = this.getAttribute('href');
        const targetElement = document.querySelector(targetId);

        if (targetElement) {
            targetElement.scrollIntoView({
                behavior: 'smooth' // Faz a rolagem suavemente
            });
        }
    });
});


// 2. Script para Alternar Conteúdo (Mostrar/Esconder - Accordion)
document.querySelectorAll('.toggle-header').forEach(header => {
    header.addEventListener('click', function() {
        // Encontra o painel de conteúdo (div.content-panel) imediatamente após este h2
        const content = this.nextElementSibling;

        // Alterna a classe 'show' no painel de conteúdo
        content.classList.toggle('show');
    });
});